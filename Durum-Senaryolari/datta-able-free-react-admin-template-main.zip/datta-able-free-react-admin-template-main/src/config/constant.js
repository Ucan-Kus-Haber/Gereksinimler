export const BASE_URL = '/app/dashboard/default';
export const BASE_TITLE = ' | Datta Able Free React Hooks + Admin Template';

export const CONFIG = {
  layout: 'vertical'
};
