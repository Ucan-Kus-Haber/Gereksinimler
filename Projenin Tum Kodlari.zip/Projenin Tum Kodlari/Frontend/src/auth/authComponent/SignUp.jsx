import React from "react";
import RegisterPage from "../RegisterPage.jsx";

function SignUp() {


    return (
        <div className="app">



                <RegisterPage/>




        </div>

    )
}

export default SignUp;