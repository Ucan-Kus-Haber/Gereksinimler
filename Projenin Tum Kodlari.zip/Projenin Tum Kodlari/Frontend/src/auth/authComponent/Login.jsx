import {LoginPage} from "../LoginPage.jsx";
import React from "react";
import './Auth.css';

function Login() {


    return (
        <div className="app">


            <div className="login-container">
                <LoginPage/>

            </div>


        </div>

    )
}

export default Login;

