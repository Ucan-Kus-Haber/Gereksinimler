import React from 'react';

const Users = () => {
    return (
        <div className="page-container">
            <h1>Users Management</h1>
            <p>This is the Users management page for the news website admin dashboard.</p>
            <div className="placeholder-content">
                <p>Here you will be able to:</p>
                <ul>
                    <li>View all registered users</li>
                    <li>Manage user roles and permissions</li>
                    <li>Moderate user comments</li>
                    <li>View user activity statistics</li>
                </ul>
            </div>
        </div>
    );
};

export default Users;
