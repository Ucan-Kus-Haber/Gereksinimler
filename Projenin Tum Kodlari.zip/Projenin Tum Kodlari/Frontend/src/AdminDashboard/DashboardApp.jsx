
import Dashboard from "./dashboard/Dashboard.jsx"
function DashboardApp(){

    return (
        <>
        <Dashboard/>
        </>

    )
}

export default DashboardApp