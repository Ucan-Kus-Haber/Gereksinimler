import Home from "./pages/Home/Home.jsx"
import AppRouter from "./AppRouter"

function App(){

    return (
        <>
        
            <AppRouter/>
        </>
    )
}

export default App;