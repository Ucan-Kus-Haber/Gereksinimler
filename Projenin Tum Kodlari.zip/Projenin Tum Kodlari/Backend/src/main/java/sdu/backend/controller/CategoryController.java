package sdu.backend.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sdu.backend.model.Category;
import sdu.backend.service.CategoryService;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    // Create a new category (with optional subcategories)
    @PostMapping
    public ResponseEntity<Category> createCategory(@RequestBody Category category) {
        Category savedCategory = categoryService.saveCategory(category);
        return ResponseEntity.ok(savedCategory);
    }

    // Get all categories
    @GetMapping
    public ResponseEntity<List<Category>> getAllCategories() {
        List<Category> categories = categoryService.getAllCategories();
        return ResponseEntity.ok(categories);
    }

    // Get a category by ID
    @GetMapping("/{id}")
    public ResponseEntity<Category> getCategoryById(@PathVariable String id) {
        Category category = categoryService.getCategoryById(id);
        return ResponseEntity.ok(category);
    }

    // Update a category by ID
    @PutMapping("/{id}")
    public ResponseEntity<Category> updateCategory(@PathVariable String id, @RequestBody Category updatedCategory) {
        Category category = categoryService.updateCategory(id, updatedCategory);
        return ResponseEntity.ok(category);
    }

    // Delete a category by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCategory(@PathVariable String id) {
        categoryService.deleteCategory(id);
        return ResponseEntity.noContent().build();
    }

    // Add a subcategory to an existing category
    @PostMapping("/{categoryId}/subcategories")
    public ResponseEntity<Category> addSubcategory(
            @PathVariable String categoryId,
            @RequestBody Category subcategory) {
        Category updatedCategory = categoryService.addSubcategoryToCategory(categoryId, subcategory);
        return ResponseEntity.ok(updatedCategory);
    }

    // Remove a subcategory from an existing category
    @DeleteMapping("/{categoryId}/subcategories/{subcategoryId}")
    public ResponseEntity<Category> removeSubcategory(
            @PathVariable String categoryId,
            @PathVariable String subcategoryId) {
        Category updatedCategory = categoryService.removeSubcategoryFromCategory(categoryId, subcategoryId);
        return ResponseEntity.ok(updatedCategory);
    }
}